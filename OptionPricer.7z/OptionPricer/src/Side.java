/**
 * 
 */

/**
 * @author Shirley Yang
 *
 */
public interface Side {

	public double put();
	public double call();
	
}
