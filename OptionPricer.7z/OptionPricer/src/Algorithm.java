/**
 * 
 */

/**
 * @version 1.0
 * @author Shirley Yang 
 * 1/3/2014
 *
 */
public abstract class Algorithm {
	
	Parameter para;

	private double calculate() {
		// TODO Auto-generated method stub
		return 0;
	}

}
