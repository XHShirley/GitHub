/**
 * 
 */

/**
 * @author Shirley Yang
 *
 */
public class AmericanOption extends Option {

	@Override
	public double put() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double call() {
		// TODO Auto-generated method stub
		return 0;
	}

}
