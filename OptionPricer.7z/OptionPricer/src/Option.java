/**
 * 
 */

/**
 * @author Shirley Yang
 *
 */
public abstract class Option extends Product implements Side{

}
